# main.py

def hello():
    print("Hello World! from Pranav Arya")