from setuptools import setup, find_packages

setup(
    name='pranavarya',
    version='0.1',
    author='Pranav Arya',
    packages=find_packages(),
    install_requires=[
        # Add your dependencies here
    ],
    # entry_points={
    #     'console_scripts': [
    #         'my_script=my_package.my_script:main',
    #     ],
    # },
)